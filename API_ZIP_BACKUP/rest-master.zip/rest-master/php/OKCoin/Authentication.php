<?php

abstract class OKCoin_Authentication {
	
	//获取成员变量
	abstract public function getData();
}
